package com.e_voting.registration;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import org.json.JSONArray;

@WebServlet("/DistrictServlet")
public class DistrictServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String state = request.getParameter("state");
        List<String> districts = new ArrayList<>();
        
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/E_voting?useSSL=false", "root", "Adit@123");

            String query = "SELECT DISTINCT district FROM users WHERE state = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, state);
            rs = ps.executeQuery();

            while (rs.next()) {
                districts.add(rs.getString("district"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException ignored) {}
            if (ps != null) try { ps.close(); } catch (SQLException ignored) {}
            if (con != null) try { con.close(); } catch (SQLException ignored) {}
        }

        // Convert list of districts to JSON array
        JSONArray jsonArray = new JSONArray(districts);
        response.setContentType("application/json");
        response.getWriter().write(jsonArray.toString());
    }
}
